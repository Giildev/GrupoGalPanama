@extends('layouts.default')
@section('content')
<div id="titulonosotros">
  <p class="titulo3">Desarrollos en Panamá</p>
</div>
<div id="contentdesarrollo">
  <div id='donwaldo'>
    <a href=#>
      <div class='phtitulos' id='donwaldofoto'><img src='".$fila['foto1']."' width='220' height='100' alt='donwaldo' /></div>
      <div class='phtitulos' id='donwaldonnombre'>Test</div>
    </a>
  </div>
</div>
@endsection
