@extends('layouts.default')
@section('content')

  <div id="contenidosocio">
    <p class="titulo4">&nbsp;</p>
    <p class="titulo4"><img src="{{asset('img/rical_logo.jpg')}}" width="229" height="229" alt="rical" /></p>
    <p class="titulo1">&nbsp;</p>
    <p class="textosa">&nbsp;</p>
  </div>

@endsection
