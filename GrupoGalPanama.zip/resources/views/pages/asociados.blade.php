@extends('layouts.default')
@section('content')
  <div id="contenidosocio">
    <p class="titulo4">&nbsp;</p>
    <p class="titulo4">ASOCIADOS GRUPO GAL</p>
    <p class="titulo1">&nbsp;</p>
    <p class="textosa">- DURLING &amp; DURLING</p>
      <p class="textosa">Web:  <a href="http://www.durlinglaw.com/" target="_blank">www.durlinglaw.com</a><br />
      </p>
      <p class="textosa">- SEA CONFIABLE</p>
      <p class="textosa">Web:  <a href="http://www.seaconfiable.com/" target="_blank">www.seaconfiable.com</a> </p>
      <p class="textosa">- ATIR BIENES RAICES</p>
      <p class="textosa">Web: <a href="http://www.atirventas.com/" target="_blank">www.atirventas.com</a></p>
  </div>
@endsection
