@extends('layouts.default')
@section('content')
  <div id="tituloprocedimiento">
<p class="titulo3">Ubicación de nuestros trabajos en desarrollo</p>
</div>

<div class="textos" id="procedimienton">
<p>&nbsp;</p>
<table width="912" align="center">
  <tr>
    <td><iframe src="https://www.google.com/maps/d/embed?mid=zdc0DlJIH3BE.ksyHyB5A1Ick" width="1020" height="600"></iframe>
      <table width="700" border="0" align="center" cellspacing="10">
        <tr>
        <td valign="top">1.Ingenio Garden
          </td>
        <td valign="top">2.New Town</td>
        <td valign="top">3.Don Waldo</td>
        <td valign="top">4.Coconut Grove</td>
        <td valign="top">5.Los Cauchos</td>
        <td valign="top">6.La Chinita</td>
      </tr>
      <tr>
        <td valign="top">7.Aserradero y Galera</td>
        <td valign="top">8.Jacha</td>
        <td valign="top">9.Alberto</td>
        <td valign="top">10.Luisa</td>
        <td valign="top">11. Los Abuelos</td>
        <td valign="top">12. Beta</td>
      </tr>
  </table>        <p>&nbsp;</p></td>
  </tr>
</table>
</div>
@endsection
