<div id="slider2_container" style="position: relative; top: 0px; left: 0px; width: 600px;height: 300px;">
<!-- Loading Screen -->
  <div u="loading" style="position: absolute; top: 0px; left: 0px;">
    <div style="filter: alpha(opacity=70); opacity:0.7; position: absolute; display: block; background-color: #000; top: 0px; left: 0px;width: 100%;height:100%;"></div>
    <div style="position: absolute; display: block; background: url(../../img/loading.gif) no-repeat center center;top: 0px; left: 0px;width: 100%;height:100%;"></div>
  </div>
<!-- Slides Container -->
  <div u="slides" style="cursor: move; position: absolute; left: 0px; top: 0px; width: 960px; height: 430px;overflow: hidden;">
    <div>
      <a u=image href="#"><img src="../images/bookie1.jpg" /></a>
    </div>
    <div>
      <a u=image href="#"><img src="../images/bookie2.jpg" /></a>
    </div>
    <div>
      <a u=image href="#"><img src="../images/bookie3.jpg" /></a>
    </div>
  </div>
  <div u="navigator" class="jssorb01" style="bottom:1px; right:70px; width:70px; height:12px; top:400px">
      <!-- bullet navigator item prototype -->
      <div u="prototype"></div>
  </div>
  <!-- Arrow Left -->
  <span u="arrowleft" class="jssora05l" style="top: 300px; left: 500px;">
  </span>
  <!-- Arrow Right -->
  <span u="arrowright" class="jssora05r" style="top: 300px; right: 500px;">
  </span>
  <a style="display: none" href="http://www.jssor.com">Bootstrap Slider</a>
  <!-- Trigger -->
  <script>
      jssor_slider2_starter('slider2_container');
  </script>
</div>
