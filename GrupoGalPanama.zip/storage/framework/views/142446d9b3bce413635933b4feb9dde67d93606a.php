<?php $__env->startSection('content'); ?>
<div id="titulonosotros">
  <p class="titulo3">Desarrollos en Panamá</p>
</div>
<div id="contentdesarrollo">
  <div id='donwaldo'>
    <a href=#>
      <div class='phtitulos' id='donwaldofoto'><img src='".$fila['foto1']."' width='220' height='100' alt='donwaldo' /></div>
      <div class='phtitulos' id='donwaldonnombre'>Test</div>
    </a>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>