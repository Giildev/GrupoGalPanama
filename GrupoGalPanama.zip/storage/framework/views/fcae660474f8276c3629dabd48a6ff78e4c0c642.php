<div id="footer">
  <span class="copyright">Copyright © GRUPO GAL 2015 </span>
</div>
<!-- JQuery -->
<script src="<?php echo e(asset('js/jquery-1.11.3.min.js')); ?>"></script>
<!-- Scripts -->
<script src="<?php echo e(asset('js/scripts.js')); ?>"></script>
<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js" integrity="sha384-0mSbJDEHialfmuBBQP6A4Qrprq5OVfW37PRR3j5ELqxss1yVqOtnepnHVP9aJ7xS" crossorigin="anonymous"></script>
